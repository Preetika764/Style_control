## replication
#write.csv(conf_wide,"D:/Dropbox/aa_students/99_old/hansin/sbirl/01.diplomacy data/conf_wide_foragreement.csv",row.names=FALSE)

## change data to long
library(reshape2)
library(tidyr)

library(dplyr)
raw_annotations<-Batch_5141348_batch_results
names(raw_annotations)

library(tidyverse)

raw_annotations <- raw_annotations %>%
  mutate(content = case_when(
    (Answer.content.1=="TRUE") ~ 1,
    (Answer.content.2=="TRUE") ~ 2,
    (Answer.content.3=="TRUE") ~ 3,
    (Answer.content.4=="TRUE") ~ 4,
    (Answer.content.5=="TRUE") ~ 5
  ))
table(raw_annotations$content)

raw_annotations <- raw_annotations %>%
  mutate(
    completeness = case_when(
      (Answer.completeness.1=="TRUE") ~ 1,
       (Answer.completeness.2=="TRUE") ~ 2,
        (Answer.completeness.3=="TRUE") ~ 3,
         (Answer.completeness.4=="TRUE") ~ 4,
          (Answer.completeness.5=="TRUE") ~ 5
    ),
    relevance = case_when(
      (Answer.relevance.1=="TRUE") ~ 1,
      (Answer.relevance.2=="TRUE") ~ 2,
      (Answer.relevance.3=="TRUE") ~ 3,
      (Answer.relevance.4=="TRUE") ~ 4,
      (Answer.relevance.5=="TRUE") ~ 5
    ),
    grammaticality = case_when(
      (Answer.grammaticality.1=="TRUE") ~ 1,
      (Answer.grammaticality.2=="TRUE") ~ 2,
      (Answer.grammaticality.3=="TRUE") ~ 3,
      (Answer.grammaticality.4=="TRUE") ~ 4,
      (Answer.grammaticality.5=="TRUE") ~ 5
    ),
    logic = case_when(
      (Answer.logic.1=="TRUE") ~ 1,
      (Answer.logic.2=="TRUE") ~ 2,
      (Answer.logic.3=="TRUE") ~ 3,
      (Answer.logic.4=="TRUE") ~ 4,
      (Answer.logic.5=="TRUE") ~ 5
    ),
    effectiveness = case_when(
      (Answer.overall.1=="TRUE") ~ 1,
      (Answer.overall.2=="TRUE") ~ 2,
      (Answer.overall.3=="TRUE") ~ 3,
      (Answer.overall.4=="TRUE") ~ 4,
      (Answer.overall.5=="TRUE") ~ 5
    ),
  )

# Display the modified data
head(raw_annotations)
names(raw_annotations)
# Display the modified data
head(raw_annotations[c(66:70)])

content<-raw_annotations[c("HITId","content")]
content_wide <- content%>%
  group_by(HITId) %>%
  mutate(annotator = paste0("annotator_", row_number())) %>%
  tidyr::pivot_wider(names_from = annotator, values_from = c(content))

grammar<-raw_annotations[c("HITId","grammaticality")]
grammar_wide <- grammar%>%
  group_by(HITId) %>%
  mutate(annotator = paste0("annotator_", row_number())) %>%
  tidyr::pivot_wider(names_from = annotator, values_from = c(grammaticality))

logic<-raw_annotations[c("HITId","logic")]
logic_wide <- logic%>%
  group_by(HITId) %>%
  mutate(annotator = paste0("annotator_", row_number())) %>%
  tidyr::pivot_wider(names_from = annotator, values_from = c(logic))

relevance<-raw_annotations[c("HITId","relevance")]
relevance_wide <- relevance%>%
  group_by(HITId) %>%
  mutate(annotator = paste0("annotator_", row_number())) %>%
  tidyr::pivot_wider(names_from = annotator, values_from = c(relevance))

completeness<-raw_annotations[c("HITId","completeness")]
completeness_wide <- completeness%>%
  group_by(HITId) %>%
  mutate(annotator = paste0("annotator_", row_number())) %>%
  tidyr::pivot_wider(names_from = annotator, values_from = c(completeness))


content_wide$item<-1:nrow(content_wide)
names(content_wide)
names(content_wide)[2:9]<-c("a1","a2","a3","a4","a5","a6","a7","a8")
content_wide$HITId<-NULL
content_long<-melt(content_wide,id.vars = "item")
names(content_long)<-c("item","annotator","rating")

completeness_wide$item<-1:nrow(completeness_wide)
names(completeness_wide)
names(completeness_wide)[2:9]<-c("a1","a2","a3","a4","a5","a6","a7","a8")
completeness_wide$HITId<-NULL
completeness_long<-melt(completeness_wide,id.vars = "item")
names(completeness_long)<-c("item","annotator","rating")

relevance_wide$item<-1:nrow(relevance_wide)
names(relevance_wide)
names(relevance_wide)[2:9]<-c("a1","a2","a3","a4","a5","a6","a7","a8")
relevance_wide$HITId<-NULL
relevance_long<-melt(relevance_wide,id.vars = "item")
names(relevance_long)<-c("item","annotator","rating")

logic_wide$item<-1:nrow(logic_wide)
names(logic_wide)
names(logic_wide)[2:9]<-c("a1","a2","a3","a4","a5","a6","a7","a8")
logic_wide$HITId<-NULL
logic_long<-melt(logic_wide,id.vars = "item")
names(logic_long)<-c("item","annotator","rating")

grammar_wide$item<-1:nrow(grammar_wide)
names(grammar_wide)
names(grammar_wide)[2:9]<-c("a1","a2","a3","a4","a5","a6","a7","a8")
grammar_wide$HITId<-NULL
grammar_long<-melt(grammar_wide,id.vars = "item")
names(grammar_long)<-c("item","annotator","rating")

#K = 2
#J = 5
#N = 90


data<-grammar_long
data<-data[complete.cases(data),]
data$rating<-as.numeric(as.character(data$rating))
data$annotator<-gsub("a","",data$annotator)
data$annotator<-as.numeric(data$annotator)
data[data==0]<-2
ii <- data[[1]];
jj <- data[[2]];
y <- data[[3]];

N <- length(ii);
K <- max(y);
J <- max(jj);
I <- max(ii);

print(paste("K=",K, "; N=",N, "; J=",J, ";I=",I));


##### EM ALGORITHM #####

### INITIALIZATION
theta_hat <- array(NA,c(J,K,K));
for (j in 1:J)
  for (k in 1:K)
    for (k2 in 1:K)
      theta_hat[j,k,k2] <- ifelse(k==k2, 0.7, 0.3/K);

pi_hat <- array(1/K,K);

### EM ITERATIONS
epoch <- 1;
min_relative_diff <- 1E-8;
last_log_posterior = - Inf;
E_z <- array(1/K, c(I,K));
MAX_EPOCHS <- 100;
for (epoch in 1:MAX_EPOCHS) {
  ### E step 
  #i<-1
  for (i in 1:I)
  
      E_z[i,] <- pi_hat;
  for (n in 1:N)
    #n<-1
    for (k in 1:K)
      #k<-1
      E_z[ii[n],k] <- E_z[ii[n],k] * theta_hat[as.numeric(jj[n]),as.numeric(k),as.numeric(y[n])];
  for (i in 1:I)
    E_z[i,] <- E_z[i,] / sum(E_z[i,]);
  
  ### M step
  beta <- 0.01; 
  pi_hat <- rep(beta,K);          # add beta smoothing on pi_hat
  for (i in 1:I)
    pi_hat <- pi_hat + E_z[i,];
  pi_hat <- pi_hat / sum(pi_hat);
  
  alpha <- 0.01;
  count <- array(alpha,c(J,K,K)); # add alpha smoothing for theta_hat
  for (n in 1:N)
    for (k in 1:K)
      count[as.numeric(jj[n]),as.numeric(k),as.numeric(y[n])] <- count[as.numeric(jj[n]),as.numeric(k),as.numeric(y[n])] + E_z[as.numeric(ii[n]),as.numeric(k)];
  for (j in 1:J)
    for (k in 1:K)
      theta_hat[j,k,] <- count[j,k,] / sum(count[j,k,]);
  
  p <- array(0,c(I,K));
  for (i in 1:I)
    p[i,] <- pi_hat;
  for (n in 1:N)
    for (k in 1:K)
      p[ii[n],k] <- p[ii[n],k] * theta_hat[as.numeric(jj[n]),as.numeric(k),as.numeric(y[n])];
  log_posterior <- 0.0;
  for (i in 1:I)
    log_posterior <- log_posterior + log(sum(p[i,]));
  if (epoch == 1)
    print(paste("epoch=",epoch," log posterior=", log_posterior));
  if (epoch > 1) {
    diff <- log_posterior - last_log_posterior;
    relative_diff <- abs(diff / last_log_posterior);
    print(paste("epoch=",epoch,
                " log posterior=", log_posterior,
                " relative_diff=",relative_diff));
    if (relative_diff < min_relative_diff) {
      print("FINISHED.");
      break;
    }
  }
  last_log_posterior <- log_posterior;
}


# VOTED PREVALENCE AS A SANITY CHECK; compare to estimates of pi
voted_prevalence <- rep(0,K);
for (k in 1:K)
  voted_prevalence[k] <- sum(y == k);
voted_prevalence <- voted_prevalence / sum(voted_prevalence);
print(paste("voted prevalence=",voted_prevalence));

pi_out <- array(0,dim=c(K,2),dimnames=list(NULL,c("category","prob")));
pos <- 1;
for (k in 1:K) {
  pi_out[pos,] <- c(k,pi_hat[k]);
  pos <- pos + 1;
}
write.table(pi_out,sep='\t',row.names=FALSE,file="pi_hat.tsv",quote=FALSE);

theta_out <- array(0,
                   dim=c(as.numeric(J)*as.numeric(K)*as.numeric(K),4),
                   dimnames=list(NULL,c("annotator","reference",
                                        "response","prob")))
pos <- 1
for (j in 1:J) {
  for (ref in 1:K) {
    for (resp in 1:K) {
      theta_out[pos,] <- c(j,ref,resp,theta_hat[j,ref,resp]);
      pos <- pos + 1;
    }
  }
}
theta_out <-data.frame(theta_out)
mean(theta_out$prob)
write.table(theta_out,
            sep='\t',
            row.names=FALSE,
            file="theta_hat.tsv",quote=FALSE);

z_out <- array(0,dim=c(I*K,3),
               dimnames=list(NULL,c("item","category","prob")));
pos <- 1;
for (i in 1:I) {
  for (k in 1:K) {
    z_out[pos,] = c(i,k,E_z[i,k]);
    pos <- pos + 1;
  }
}
write.table(z_out,sep='\t',row.names=FALSE,file="z_hat.tsv",quote=FALSE)
library(dplyr)
z_out<-data.frame(z_out)
result <- z_out %>%
  group_by(item) %>%
  filter(prob == max(prob)) %>%
  ungroup()

print(result)
head(theta_out)

### keep only the theta for the high-probability answers
library(dplyr)
head(result)
head(theta_out)
filtered_theta_out <- theta_out %>%
  semi_join(result, by = c("reference"="item", "response" = "category"))

print(filtered_theta_out)
mean(filtered_theta_out$prob)
mean(result$prob)
